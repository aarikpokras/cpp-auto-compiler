# thxgen-c
[thxgen](https://github.com/tymaker-team/thxgen), but in C++

G++ compiler required.
## Building
Enter the directory to which you have downloaded thxgen-c.

```console
./build.sh && clear && ./thxgen
```
If build.sh will not run, then run this:

```console
chmod +x build.sh
```
