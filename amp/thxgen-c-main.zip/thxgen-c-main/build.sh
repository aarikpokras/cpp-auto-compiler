#!/bin/sh
g++ -o thxgen thxgen-c.cpp
